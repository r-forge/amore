/*
 * AdaptNeuronTrainBehavior.cpp
 *
 *  Created on: 09/08/2011
 *      Author: mcasl
 */
//=========================================================================================================

#include "package.h"
#include "classHeaders/AdaptNeuronTrainBehavior.h"

AdaptNeuronTrainBehavior::AdaptNeuronTrainBehavior(NeuronPtr neuronPtr) :
    MLPNeuronTrainBehavior(neuronPtr)
{
}

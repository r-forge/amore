/*
 * ADAPTgdwmFactory.cpp
 *
 *  Created on: 5/08/2011
 *      Author: mcasl
 */
//=========================================================================================================

#include "package.h"
#include "classHeaders/ADAPTgdwmFactory.h"
#include "classHeaders/ADAPTgdwmNetworkTrainBehavior.h"
#include "classHeaders/ADAPTgdwmOutputNeuronTrainBehavior.h"
#include "classHeaders/ADAPTgdwmHiddenNeuronTrainBehavior.h"


NetworkTrainBehaviorPtr
ADAPTgdwmFactory::makeNetworkTrainBehavior(NeuralNetworkPtr neuralNetworkPtr)
{
  NetworkTrainBehaviorPtr networkTrainBehaviorPtr(new ADAPTgdwmNetworkTrainBehavior(neuralNetworkPtr));
  return  networkTrainBehaviorPtr;
}



NeuronTrainBehaviorPtr
ADAPTgdwmFactory::makeOutputNeuronTrainBehavior(NeuronPtr neuronPtr)
{
  NeuronTrainBehaviorPtr neuronTrainBehaviorPtr( new ADAPTgdwmOutputNeuronTrainBehavior(neuronPtr) );
  return  neuronTrainBehaviorPtr;
}

NeuronTrainBehaviorPtr
ADAPTgdwmFactory::makeHiddenNeuronTrainBehavior(NeuronPtr neuronPtr)
{
  NeuronTrainBehaviorPtr neuronTrainBehaviorPtr( new ADAPTgdwmHiddenNeuronTrainBehavior(neuronPtr) );
  return  neuronTrainBehaviorPtr;
}

/*
 * AdaptNetworkTrainBehavior.cpp
 *
 *  Created on: 9/08/2011
 *      Author: mcasl
 */

#include "package.h"
#include "classHeaders/AdaptNetworkTrainBehavior.h"

AdaptNetworkTrainBehavior::AdaptNetworkTrainBehavior( NeuralNetworkPtr neuralNetworkPtr) :
  MLPNetworkTrainBehavior(neuralNetworkPtr)
{
}


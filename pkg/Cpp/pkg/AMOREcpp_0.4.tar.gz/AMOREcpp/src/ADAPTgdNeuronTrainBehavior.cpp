/*
 * ADAPTgdNeuronTrainBehavior.cpp
 *
 *  Created on: 09/08/2011
 *      Author: mcasl
 */
//=========================================================================================================

#include "package.h"
#include "classHeaders/ADAPTgdNeuronTrainBehavior.h"

ADAPTgdNeuronTrainBehavior::ADAPTgdNeuronTrainBehavior(NeuronPtr neuronPtr) :
  AdaptNeuronTrainBehavior(neuronPtr)
{
}

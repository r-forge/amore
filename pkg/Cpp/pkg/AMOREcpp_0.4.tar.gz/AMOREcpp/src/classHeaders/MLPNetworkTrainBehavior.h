#pragma once
#include "NetworkTrainBehavior.h"

/// class MLPNetworkTrainBehavior - 
class MLPNetworkTrainBehavior : public NetworkTrainBehavior {
  // Operations
protected:
  MLPNetworkTrainBehavior (NeuralNetworkPtr neuralNetworkPtr);
};


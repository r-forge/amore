#pragma once
#include "MLPNetworkTrainBehavior.h"

/// class BatchNetworkTrainBehavior - 
class BatchNetworkTrainBehavior : public MLPNetworkTrainBehavior {
  // Operations
protected:
  BatchNetworkTrainBehavior (NeuralNetworkPtr neuralNetworkPtr);
};

